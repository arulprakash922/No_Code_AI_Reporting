import calendar
import dateparser
from flask import Flask, render_template, request
import psycopg2
from transformers import T5Tokenizer, T5ForConditionalGeneration
from datetime import datetime
import spacy
from transformers import AutoTokenizer, AutoModelForQuestionAnswering
import torch

app = Flask(__name__)

# PostgreSQL configuration
db_host = 'localhost'
db_name = 'postgres'
db_user = 'postgres'
db_password = '2004'

# Load the spaCy model (English)
nlp = spacy.load("en_core_web_sm")

# Replace "path/to/t5_model" with the actual path to your locally saved model folder
model_path = "t5"
tokenizer = T5Tokenizer.from_pretrained(model_path)
model = T5ForConditionalGeneration.from_pretrained(model_path)

column_mapping = {
    "Date": "date",
    "Precipitation": "precipitation",
    "MAX Temperature": "temp_max",
    "MIN Temperature": "temp_min",
    "Wind": "wind",
    "Weather": "weather"
}

def convert_date_format(date_str):
     date_obj = dateparser.parse(str(date_str))
     if date_obj:
         formatted_date = date_obj.strftime('%d-%m-%Y')
         return formatted_date
     else:
         return "Invalid date format"

def format_date(date_str):
    # Convert the date to "DD-MM-YYYY" format
    formatted_date = convert_date_format(date_str)
    return formatted_date

def extract_and_format_dates(text):
    doc = nlp(text)
    dates = [ent.text for ent in doc.ents if ent.label_ == "DATE"]
    return dates

def get_sql(query):
    input_text = "translate English to SQL: %s" % query
    inputs = tokenizer.encode(input_text, return_tensors="pt")
    
    outputs = model.generate(inputs)
    generated_sql_query = tokenizer.decode(outputs[0], skip_special_tokens=True)
    generated_sql_query = generated_sql_query.replace("table", "weather_data")
    generated_sql_query = generated_sql_query.replace("Day","weather")
    
    for word in column_mapping.keys():
        generated_sql_query = generated_sql_query.replace(word, column_mapping[word])

    formatted_dates_1 = extract_and_format_dates(query)
    doc = nlp(query)
    for ent, formatted_date in zip(doc.ents, formatted_dates_1):
        if ent.label_ == "DATE":
            if formatted_dates_1:
                formatted_date_with_year = convert_date_format(formatted_date)  
                generated_sql_query = generated_sql_query.replace(f"'{formatted_dates_1}'", f"'{formatted_date_with_year}'")
                print('\n\n out query',generated_sql_query)
            else:
                raise ValueError("Invalid date format in the input")
    generated_sql_query += ";"

    if "days" in query.lower():
        if "rain" in query.lower():
            column= "SELECT COUNT(*) AS condition_count FROM weather_data WHERE weather = 'rain';"
            return  column
        if "sun" in query.lower():
            column= "SELECT COUNT(*) AS condition_count FROM weather_data WHERE weather = 'sun';"
            return  column
        if "snow" in query.lower():
            column= "SELECT COUNT(*) AS condition_count FROM weather_data WHERE weather = 'snow';"
            return  column
        if "fog" in query.lower():
            column= "SELECT COUNT(*) AS condition_count FROM weather_data WHERE weather = 'fog';"
            return  column
        if "drizzle" in query.lower():
            column= "SELECT COUNT(*) AS condition_count FROM weather_data WHERE weather = 'drizzle';"
            return  column
    
    
    elif "average" in query.lower():
    # Check if the query is related to temperature, wind, or precipitation
        if "temperature" in query.lower():
            avg_column_max = "temp_max"  
            avg_column_min = "temp_min"  
        
            avg_query_max = f"SELECT AVG(CAST({avg_column_max} AS Float)) FROM weather_data;"
            avg_query_min = f"SELECT AVG(CAST({avg_column_min} AS Float)) FROM weather_data;"
            
            if 'maximum' in  query.lower():
                return avg_query_max
            if 'minimum' in  query.lower():
                return avg_query_min
    
        if "wind" in query.lower():
            avg_column_wind = "wind"  # Use the appropriate column name for wind speed
        
            avg_query_wind = f"SELECT AVG(CAST({avg_column_wind} AS Float)) FROM weather_data;"
        
            return avg_query_wind  # Return average query for wind speed
    
        if "precipitation" in query.lower():
            avg_column_precip = "precipitation"  # Use the appropriate column name for precipitation
        
            avg_query_precip = f"SELECT AVG(CAST({avg_column_precip} AS Float)) FROM weather_data;"
        
            return avg_query_precip  # Return average query for precipitation
    
    return generated_sql_query
        
# Function to execute SQL queries against PostgreSQL
def execute_query(sql_query):
    connection = psycopg2.connect(
        host=db_host,
        dbname=db_name,
        user=db_user,
        password=db_password
    )
    cursor = connection.cursor()
    cursor.execute(sql_query)
    results = cursor.fetchall()
    connection.close()
    return results

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        sentence = request.form['sentence']
        # Use your T5 model to convert the sentence into an SQL query
        sql_query = get_sql(sentence)

        # Execute the SQL query
        results = execute_query(sql_query)

        return render_template('result.html', sentence=sentence, sql_query=sql_query, results=results)

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
