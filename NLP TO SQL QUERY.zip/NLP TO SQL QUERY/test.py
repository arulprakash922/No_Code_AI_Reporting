import calendar
from flask import Flask, render_template, request
import psycopg2
from transformers import T5Tokenizer, T5ForConditionalGeneration
from datetime import datetime
import dateparser
import spacy
import warnings
from transformers import T5Tokenizer, T5ForConditionalGeneration
# Suppress the FutureWarning from the transformers library
warnings.simplefilter(action='ignore', category=FutureWarning)

app = Flask(__name__)

# PostgreSQL configuration
db_host = 'localhost'
db_name = 'weather_data'
db_user = 'postgres'
db_password = '2004'

# Load the spaCy model (English)
nlp = spacy.load("en_core_web_sm")

# Replace "path/to/t5_model" with the actual path to your locally saved model folder
model_path = "t5"
tokenizer = T5Tokenizer.from_pretrained(model_path)
model = T5ForConditionalGeneration.from_pretrained(model_path)

column_mapping = {
    "Date": "date",
    "Precipitation": "precipitation",
    "MAX Temperature": "temp_max",
    "MIN Temperature": "temp_min",
    "Wind": "wind",
    "Weather": "weather"
}

def convert_date_format(date_str):
    date_obj = dateparser.parse(date_str)
    if date_obj:
        formatted_date = date_obj.strftime('%d-%m-%Y')
        return formatted_date
    else:
        formats_to_try = [
            '%B %d,%Y',     # January 12,2020
            '%B %d, %Y',    # January 12, 2020
            '%d %B %Y',     # 12 January 2020
            '%d-%m-%Y',     # 12-01-2020
            '%d/%m/%Y',     # 12/01/2020
            '%m-%d-%Y',     # 01-12-2020
            '%m/%d/%Y',     # 01/12/2020
        ]

        for format_str in formats_to_try:
            try:
                date_obj = datetime.strptime(date_str, format_str)
                formatted_date = date_obj.strftime('%d-%m-%Y')
                return formatted_date
            except ValueError:
                continue

        raise ValueError("Invalid date format")

def format_date(date_str):
    # Convert the date to "DD-MM-YYYY" format
    formatted_date = convert_date_format(date_str)
    return formatted_date

def extract_and_format_dates(text):
    doc = nlp(text)
    dates = [ent.text for ent in doc.ents if ent.label_ == "DATE"]

    formatted_dates = [format_date(date_str) for date_str in dates]
    return formatted_dates

def get_sql(query):
    input_text = "translate English to SQL: %s </s>" % query
    inputs = tokenizer.encode(input_text, return_tensors="pt")
    outputs = model.generate(inputs)

    # Remove special tokens and decode the generated SQL query
    generated_sql_query = tokenizer.decode(outputs[0], skip_special_tokens=True)

    # Replace "table" with "weather_data"
    generated_sql_query = generated_sql_query.replace("table", "weather_data")

    # Find and replace generated words with column names using the mapping
    for word in column_mapping.keys():
        generated_sql_query = generated_sql_query.replace(word, column_mapping[word])

    # Extract and format dates from the input
    formatted_dates = extract_and_format_dates(query)

    # Replace date placeholders with formatted dates in "DD-MM-YYYY" format
    doc = nlp(query)
    for ent, formatted_date in zip(doc.ents, formatted_dates):
        if ent.label_ == "DATE":
            if formatted_date:
                formatted_date = convert_date_format(formatted_date)  # Format date in SQL query
                # Replace the date placeholder with the formatted date in SQL query
                generated_sql_query = generated_sql_query.replace(f"{ent.text} </s>", f"'{formatted_date}'")
            else:
                raise ValueError("Invalid date format in the input")

    # Add semicolon to the end of the SQL query
    generated_sql_query += ";"

    return generated_sql_query

# Function to execute SQL queries against PostgreSQL
def execute_query(sql_query):
    connection = psycopg2.connect(
        host=db_host,
        dbname=db_name,
        user=db_user,
        password=db_password
    )
    cursor = connection.cursor()
    cursor.execute(sql_query)
    results = cursor.fetchall()
    connection.close()
    return results

sentence = input('enter the question:')
        # Use your T5 model to convert the sentence into an SQL query
sql_query = get_sql(sentence)

        # Execute the SQL query
result = execute_query(sql_query)
print(result)